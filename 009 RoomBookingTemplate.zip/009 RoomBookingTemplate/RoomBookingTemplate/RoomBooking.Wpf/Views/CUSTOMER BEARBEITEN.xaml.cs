﻿using RoomBooking.Core.Entities;
using RoomBooking.Core.Validations;
using RoomBooking.Persistence;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RoomBooking.Wpf.Views
{
    /// <summary>
    /// Interaction logic for CUSTOMER_BEARBEITEN.xaml
    /// </summary>
    public partial class CUSTOMER_BEARBEITEN : Window
    {
        public CUSTOMER_BEARBEITEN()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(EditCustomer_Loaded);
        }

         void EditCustomer_Loaded(object sender, RoutedEventArgs e)
        {
            btSave.Click += new RoutedEventHandler(btSave_Click);
            btUndo.Click += new RoutedEventHandler(btUndo_Click);
        }

        private void btUndo_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void btSave_Click(object sender, RoutedEventArgs e)
        {
            Customer cust = new Customer();
            cust.LastName = ctLastName.Text;
            cust.FirstName = ctFirstName.Text;
            cust.Iban = ctIban.Text;

            IbanChecker.CheckIban(cust.Iban);

            //CustomerRepository.GetAllByAscinc();

        }
    }
}
