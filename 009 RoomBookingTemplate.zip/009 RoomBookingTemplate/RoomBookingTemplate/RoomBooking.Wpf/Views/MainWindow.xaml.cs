﻿using RoomBooking.Core.Entities;
using RoomBooking.Persistence;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Documents;

namespace RoomBooking.Wpf.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow 
    {
        List<Customer> _customer;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(MainWindow_Loaded);
        }

        void MainWindow_Loaded(object number, RoutedEventArgs e)
        {
            CustomerRepository rep = CustomerRepository();
            _customer = rep.GetAllAsync();

            custRoom.ItemsSource = _customer();

            btEdit.Click += new RoutedEventHandler(btEdit_Click);
        }


         void btEdit_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            CUSTOMER_BEARBEITEN editCustomer = new CUSTOMER_BEARBEITEN();
            editCustomer.ShowDialog();
        }
    }
}