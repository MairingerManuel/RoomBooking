﻿using System;

namespace RoomBooking.ImportConsole
{
  class Program
  {
    static void Main()
    {
      Console.WriteLine("Hello World!");
    }
  }
}
